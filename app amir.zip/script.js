// script.js
let currentLanguage = 'ar'; // اللغة الافتراضية

const translations = {
    ar: {
        appTitle: "تطبيق حفظ البيانات المتطور",
        phonePlaceholder: "رقم الهاتف",
        emailPlaceholder: "البريد الإلكتروني",
        passwordPlaceholder: "كلمة المرور",
        saveButton: "حفظ البيانات",
        clearAll: "مسح كل المعلومات",
        exportData: "تصدير البيانات",
        importData: "استيراد البيانات",
        qrcodeTitle: "QR Code للبيانات",
        edit: "تعديل",
        delete: "حذف",
        dataDeleted: "تم مسح جميع البيانات بنجاح!",
        dataExported: "تم تصدير البيانات بنجاح!",
        dataImported: "تم استيراد البيانات بنجاح!"
    },
    en: {
        appTitle: "Advanced Data Saver",
        phonePlaceholder: "Phone Number",
        emailPlaceholder: "Email",
        passwordPlaceholder: "Password",
        saveButton: "Save Data",
        clearAll: "Clear All Data",
        exportData: "Export Data",
        importData: "Import Data",
        qrcodeTitle: "Data QR Code",
        edit: "Edit",
        delete: "Delete",
        dataDeleted: "All data has been deleted successfully!",
        dataExported: "Data has been exported successfully!",
        dataImported: "Data has been imported successfully!"
    }
};

function setLanguage(language) {
    currentLanguage = language;
    document.getElementById('appTitle').textContent = translations[language].appTitle;
    document.getElementById('phone').placeholder = translations[language].phonePlaceholder;
    document.getElementById('email').placeholder = translations[language].emailPlaceholder;
    document.getElementById('password').placeholder = translations[language].passwordPlaceholder;
    document.getElementById('saveButton').textContent = translations[language].saveButton;
    document.getElementById('clearAll').textContent = translations[language].clearAll;
    document.getElementById('exportData').textContent = translations[language].exportData;
    document.getElementById('importData').textContent = translations[language].importData;
    document.getElementById('qrcodeTitle').textContent = translations[language].qrcodeTitle;
}

document.getElementById('switchLanguage').addEventListener('click', function() {
    const newLanguage = currentLanguage === 'ar' ? 'en' : 'ar';
    setLanguage(newLanguage);
    this.textContent = newLanguage === 'ar' ? 'English' : 'العربية';
});

document.getElementById('dataForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const data = {
        phone,
        email,
        password
    };

    saveData(data);
    displayData();
    generateQRCode(data);
    document.getElementById('dataForm').reset();
});

document.getElementById('clearAll').addEventListener('click', function() {
    localStorage.removeItem('savedData');
    displayData();
    document.getElementById('qrcode').innerHTML = '';
    alert(translations[currentLanguage].dataDeleted);
});

document.getElementById('exportData').addEventListener('click', function() {
    const savedData = JSON.parse(localStorage.getItem('savedData')) || [];
    if (savedData.length === 0) {
        alert("لا توجد بيانات لتصديرها!");
        return;
    }
    const dataStr = JSON.stringify(savedData, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'data.json';
    a.click();
    URL.revokeObjectURL(url);
    alert(translations[currentLanguage].dataExported);
});

document.getElementById('importData').addEventListener('click', function() {
    document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const importedData = JSON.parse(e.target.result);
            const savedData = JSON.parse(localStorage.getItem('savedData')) || [];
            const newData = [...savedData, ...importedData];
            localStorage.setItem('savedData', JSON.stringify(newData));
            displayData();
            alert(translations[currentLanguage].dataImported);
        } catch (error) {
            alert("خطأ في استيراد البيانات: ملف غير صالح!");
        }
    };
    reader.readAsText(file);
});

function saveData(data) {
    let savedData = JSON.parse(localStorage.getItem('savedData')) || [];
    savedData.push(data);
    localStorage.setItem('savedData', JSON.stringify(savedData));
}

function displayData() {
    const dataList = document.getElementById('dataList');
    dataList.innerHTML = '';

    let savedData = JSON.parse(localStorage.getItem('savedData')) || [];

    savedData.forEach((data, index) => {
        const dataItem = document.createElement('div');
        dataItem.className = 'data-item';

        dataItem.innerHTML = `
            <p><strong>${translations[currentLanguage].phonePlaceholder}:</strong> ${data.phone}</p>
            <p><strong>${translations[currentLanguage].emailPlaceholder}:</strong> ${data.email}</p>
            <p><strong>${translations[currentLanguage].passwordPlaceholder}:</strong> ${data.password}</p>
            <button class="edit" onclick="editData(${index})">${translations[currentLanguage].edit}</button>
            <button class="delete" onclick="deleteData(${index})">${translations[currentLanguage].delete}</button>
        `;

        dataList.appendChild(dataItem);
    });
}

function editData(index) {
    let savedData = JSON.parse(localStorage.getItem('savedData')) || [];
    const data = savedData[index];

    document.getElementById('phone').value = data.phone;
    document.getElementById('email').value = data.email;
    document.getElementById('password').value = data.password;

    savedData.splice(index, 1);
    localStorage.setItem('savedData', JSON.stringify(savedData));
    displayData();
}

function deleteData(index) {
    let savedData = JSON.parse(localStorage.getItem('savedData')) || [];
    savedData.splice(index, 1);
    localStorage.setItem('savedData', JSON.stringify(savedData));
    displayData();
}

function generateQRCode(data) {
    const qrcodeDiv = document.getElementById('qrcode');
    qrcodeDiv.innerHTML = '';

    const qrData = JSON.stringify(data);
    new QRCode(qrcodeDiv, {
        text: qrData,
        width: 150,
        height: 150
    });
}

// تعيين اللغة الافتراضية عند التحميل
window.onload = function() {
    setLanguage('ar');
    displayData();
};